const fs = require('fs'); const cp = require('child_process'); const os = require('os'); const path = require('path');
const F = process.argv[2];
function rd(p){ return fs.readFileSync(p,'utf8'); }
function cnt(h,n){ let i=0,c=0; while((i=h.indexOf(n,i))!==-1){c++;i+=n.length;} return c; }
let s = rd(F); const orig = s; const warn = [];
function req(oldB, newB, label){ const c=cnt(s,oldB); if(c!==1){ console.error('ABORT: ['+label+'] found '+c+' (need 1) — nothing written'); process.exit(2);} s = s.split(oldB).join(newB); }
function opt(oldB, newB, label){ const c=cnt(s,oldB); if(c===1){ s = s.split(oldB).join(newB); } else { warn.push(label+' (found '+c+', skipped)'); } }
req('</style>', rd('PICKER_CSS.txt') + '</style>', 'picker CSS');
req('var PICKED_EMAIL = null;\n', 'var PICKED_EMAIL = null;\n\n' + rd('PICKER_JS.txt') + '\n', 'picker JS');
req(rd('OLD_card.txt'), rd('NEW_card.txt'), 'rules card markup');
req(rd('OLD_toggleRule.txt'), rd('NEW_toggleRule.txt'), 'toggleRule');
req(rd('OLD_saveRule.txt'), rd('MANAGER_JS.txt'), 'saveRule -> manager');
req(rd('OLD_applyAutoRule.txt'), rd('NEW_applyAutoRule.txt'), 'applyAutoRule');
req(rd('OLD_fineTune.txt'), rd('NEW_fineTune.txt'), 'fineTune');
req(rd('OLD_openApplyModal.txt'), rd('NEW_openApplyModal.txt'), 'openApplyModal');
opt(rd('OLD_testProductRule.txt'), '// testProductRule removed (replaced by per-rule 🧪 test)\n', 'remove testProductRule');
const m = s.match(/<script>([\s\S]*?)<\/script>/);
if(!m){ console.error('ABORT: no <script> block — nothing written'); process.exit(3); }
const js = m[1].replace(/<%[-=]?[\s\S]*?%>/g, 'null');
const tmp = path.join(os.tmpdir(), '_lnk_'+process.pid+'.js'); fs.writeFileSync(tmp, js);
try { cp.execSync('node --check ' + tmp, { stdio:'pipe' }); } catch(e){ console.error('ABORT: patched <script> failed node --check — nothing written'); console.error(String(e.stderr||e.message).split('\n').slice(0,4).join('\n')); try{fs.unlinkSync(tmp);}catch(_){}; process.exit(4); }
fs.unlinkSync(tmp);
fs.writeFileSync(F + '.bak-centersv2', orig); fs.writeFileSync(F, s);
console.log('LINK PAGE PATCHED OK + <script> validated (backup: .bak-centersv2)');
if (warn.length) console.log('NOTE (non-fatal): ' + warn.join('; '));
